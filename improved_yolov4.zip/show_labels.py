import cv2
import numpy as np
import pandas as pd
from tqdm import tqdm
import json
import os


def get_xyxy(img, json_label):
    xy_list = []  # x_min,y_min,x_max,y_max
    with open(json_label) as f:
        # jdata = {'shape':.., 'imagePath':...}
        jdata = json.load(f)
        name = jdata['imagePath'][:-4]
        # jdata['shape'] -> list
        # 每一个成员又是一个dict
        # {'label':pig, 'boxes':[x-min,y-min,x-max,y-max], 'points':None}  # boxes
        # {'label':pig, 'boxes':None, 'points':[[x1,y1],[x2,y2],...,[xn,yn]]}  # points
        for dict in jdata['shape']:
            points = dict['points']
            x_max, x_min = 0, img.shape[1]
            y_max, y_min = 0, img.shape[0]
            # get (x_min,y_min,x_max,y_max)
            for point in points:
                x, y = point
                if x > x_max:
                    x_max = x
                if x < x_min:
                    x_min = x
                if y > y_max:
                    y_max = y
                if y < y_min:
                    y_min = y
            print('%d,%d %d,%d' % (x_min, y_min, x_max, y_max))
            xy_list.append([x_min, y_min, x_max, y_max])
    return xy_list


def get_xyxy_from_cowboy(img_name, df, json_label):
    xy_list = []
    fname_id_dict = {}
    for idx, row in df.iterrows():
        fname_id_dict.update({row['file_name']: row['id']})
    print('len(valid)=', len(fname_id_dict))
    with open(json_label) as f:
        jdata = json.load(f)
        for dict in tqdm(jdata):
            image_id = fname_id_dict[img_name]
            if image_id == dict['image_id']:
                # x_min, y_min, x_max, y_max = dict['bbox']
                x, y, w, h = dict['bbox']
                x_min, y_min, x_max, y_max = x, y, x + w, y + h
                xy_list.append([int(x_min), int(y_min), int(x_max), int(y_max)])

    return xy_list


def draw_rect(img, xy_list):
    for xy in xy_list:
        cv2.rectangle(img, (xy[0], xy[1]), (xy[2], xy[3]), (0, 0, 255), 2)


def get_xyxy_from_yolo(img, txt):
    xy_list = []
    img_w, img_h = img.shape[1], img.shape[0]
    with open(txt) as f:
        for line in f:
            line = line.strip().split()
            x, y, w, h = map(float, line[1:])

            x, w = x * img_w, w * img_w
            y, h = y * img_h, h * img_h
            x_min, x_max = int(x - w / 2.0), int(x + w / 2.0)
            y_min, y_max = int(y - h / 2.0), int(y + h / 2.0)
            xy_list.append([x_min, y_min, x_max, y_max])
    return xy_list


if __name__ == '__main__':
    dataset_path = 'bdd100k_rs/val/images'
    txt = 'bdd100k_rs/val/labels/b1cac6a7-04e33135.txt'
    img_name = "b1cac6a7-04e33135.jpg"
    # img_name = df['file_name'].sample(1).tolist()[0]
    # json_label = r'answer.json'

    print(img_name)
    img = cv2.imread(os.path.join(dataset_path, img_name))
    print(img.shape)  # (h,w,c)

    xy_list = get_xyxy_from_yolo(img, txt)
    draw_rect(img, xy_list)

    cv2.namedWindow('Image', 0)
    cv2.imshow('Image', img)
    cv2.waitKey(0)
